<?php

spl_autoload_register(function(string $classname)
{
    if(file_exists("classes/$classname.php"))
    {
        require_once("classes/$classname.php");
    }
    elseif(strpos($classname, "Page") !== false && file_exists("classes/pageControllers/$classname.php"))
    {
        require_once("classes/pageControllers/$classname.php");
    }
});
