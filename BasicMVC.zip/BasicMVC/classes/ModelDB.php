<?php

abstract class ModelDB
{
    private static PDO $pdo;
    
    public static function Init()
    {
        self::$pdo = new PDO("mysql:host=localhost;dbname=basicmvc", "php", "123456aA");
        self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    
    public static function GetPage(string $key) : bool|array
    {
        try
        {
            $result = self::$pdo->query("SELECT * FROM `pages` WHERE `key` = ".self::$pdo->quote($key));
            if($result->rowCount() == 1)
            {
                $data = $result->fetchAll(PDO::FETCH_DEFAULT)[0];
                $result->closeCursor();
                return $data;
            }
            return false;
        } 
        catch (Exception $ex) 
        {
            
        }
    }
    
    public static function GetUser(string $email) : bool|array
    {
        try
        {
            $result = self::$pdo->prepare("SELECT * FROM `users` WHERE `email` = :email");
            $result->bindParam(':email', $email, PDO::PARAM_STR);
            $result->execute();

            if($result->rowCount() == 1)
            {
                $data = $result->fetch(PDO::FETCH_ASSOC);
                $result->closeCursor();
                return $data;
            }
            return false;
        } 
        catch (Exception $ex) 
        {
            throw new DBException("Sikertelen felhasználó lekérdezés!", $ex);
        }
    }
    
    public static function LoginUser(string $email, string $encpassword) : bool|array
{
    try
    {
        $userData = self::getUserDataByEmail($email);

        // Sikertelen bejelentkezés, ha nincs felhasználó vagy a jelszó nem egyezik
        if (!$userData || !self::comparePasswords($encpassword, $userData['password'])) {
            return false;
        }

        // Sikeres bejelentkezés
        return $userData;
    } 
    catch (Exception $ex) 
    {
        throw new DBException("Sikertelen beléptetés!", $ex);
    }
}

    private static function getUserDataByEmail(string $email): bool|array
    {
        $result = self::$pdo->prepare("SELECT * FROM `users` WHERE `email` = :email");
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->execute();

        if ($result->rowCount() == 1) {
            $userData = $result->fetch(PDO::FETCH_ASSOC);
            $result->closeCursor();
            return $userData;
        }

        return false;
    }

    private static function comparePasswords(string $encpassword, string $storedPassword): bool
    {
        // Jelszó összehasonlítása
            return hash_equals($storedPassword, $encpassword);
    }

        public static function RegisterUser(string $name, string $email, string $encodedPass) : void
        {
            try
            {
                $result = self::$pdo->prepare("INSERT INTO `users` VALUES (:email, :name, :password)");
                $result->bindParam(':email', $email, PDO::PARAM_STR);
                $result->bindParam(':name', $name, PDO::PARAM_STR);
                $result->bindParam(':password', $encodedPass, PDO::PARAM_STR);
                $result->execute();
            } 
            catch (Exception $ex) 
            {
                throw new DBException("Sikertelen regisztráció!", $ex);
            }
        }
    }
