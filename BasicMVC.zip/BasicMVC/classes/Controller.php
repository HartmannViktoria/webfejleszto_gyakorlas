<?php

class Controller
{    
    public static function Init() : void
    {
        ModelDB::Init();
        View::Init("index.html");
    }
        
    public static function Route()
    {
        if(isset($_GET["page"]))
        {
            $page = htmlspecialchars($_GET["page"]);
        }
        elseif(isset($_SESSION["name"]))
        {
            $page = "main";
        }
        else
        {
            $page = "welcome";
        }

        $pageData = ModelDB::GetPage($page);
        if($pageData != false)
        {
            $subPageTemplate = call_user_func(array(ucfirst($page)."Page", "Run"));
            if($pageData[2] != "false")
            {
                $pageTemplate = Template::Load("{$pageData[2]}.html");
                $pageTemplate->AddData("PAGECONTENT", $subPageTemplate->Render());
            }
            else
            {
                $pageTemplate = $subPageTemplate;
            }
        }
        else
        {
            $pageTemplate = self::Error404Controller();
        }
        View::getBaseTemplate()->AddData("CONTENT", $pageTemplate->Render());
    }
    
    
    private static function Error404Controller() : Template
    {
        $template = Template::Load("notFound.html");
        $template->AddData("CONTENT", "Az oldal nem létezik!");
        $template->AddData("TITLE", "A megadott oldal nem található!");
        return $template;
    }
       
}
