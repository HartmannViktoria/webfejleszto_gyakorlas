<?php

class NotAllowedPage
{
    public static function Run() : Template
    {
        $template = Template::Load("notAllowed.html");
        $template->AddData("CONTENT", "A megadott oldal megtekintéséhez előbb jelentkezzen be!");
        return $template;
    }
}
