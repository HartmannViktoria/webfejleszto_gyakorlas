<?php

class UsersPage
{
    public static function Run() : Template
    {
        if(isset($_SESSION["name"]))
        {
            $template = Template::Load("users.html");
            $template->AddData("TITLE", "Felhasználók");
            $tableData = Model::ReadCSV("users");
            $tableContent = "";
            foreach($tableData["data"] as $row)
            {
                $rowTemplate = Template::Parse("<tr><td>§NAME§</td><td>§EMAIL§</td><td>§PASS§</td></tr>");
                $rowTemplate->AddData("NAME", $row[0]);
                $rowTemplate->AddData("EMAIL", $row[1]);
                $rowTemplate->AddData("PASS", $row[2]);
                $tableContent .= $rowTemplate->Render();
            }
            $template->AddData("USERS", $tableContent);
            return $template;
        }
        header("Location: index.php?page=notAllowed");
        return Template::Parse("");
    }
}
