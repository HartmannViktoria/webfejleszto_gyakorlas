<?php

class Vedett1Page
{
    public static function Run() : Template
    {
        if(isset($_SESSION["name"]))
        {
            $template = Template::Load("vedett1.html");
            $template->AddData("TITLE", "Védett oldal");
            return $template;
        }
        header("Location: index.php?page=notAllowed");
        return Template::Parse("");
    }
}
