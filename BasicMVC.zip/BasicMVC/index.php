<?php
session_start();
require_once("autoloader.php");
Controller::Init();
Controller::Route();
View::FinalRender();