
function toggleSections(sectionToShow) {
    let welcomeSection = document.getElementById('welcome-section');
    let loginSection = document.getElementById('login-section');
    let registerSection = document.getElementById('register-section');

    if (sectionToShow === 'login') {
        welcomeSection.style.display = 'none';
        loginSection.style.display = 'block';
        registerSection.style.display = 'none';
    } else if (sectionToShow === 'register') {
        welcomeSection.style.display = 'none';
        loginSection.style.display = 'none';
        registerSection.style.display = 'block';
    } else {
        welcomeSection.style.display = 'block';
        loginSection.style.display = 'none';
        registerSection.style.display = 'none';
    }
};
