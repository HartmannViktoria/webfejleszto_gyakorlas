<?php

class Model
{
    public static function ReadCSV(string $name, string $separator = ";", bool $header = false): array
    {
        $data = fopen("data/$name.csv", "r");
        $result = array();
        if ($header) {
            $result["header"] = fgetcsv($data, null, $separator);
        }
        while (!feof($data)) {
            $row = fgetcsv($data, null, $separator);
            if (is_array($row)) {
                $result["data"][] = $row;
            }
        }
        fclose($data);
        return $result;
    }

    public static function WriteCSV(string $name, array $data, string $separator = ";", bool $append = false): void
    {
        $file = fopen("data/$name.csv", $append ? "a" : "w");
        foreach ($data as $rowData) {
            if (is_array($rowData)) {
                fputcsv($file, $rowData, $separator);
            } else {
                fputs($file, $rowData . "\n");
            }
        }
        fclose($file);
    }

    public static function AddUser(array $userData): void
    {
        $users = self::ReadCSV("users.csv", ";", true);
        $users["data"][] = $userData;
        self::WriteCSV("users.csv", $users["data"], ";", false);
    }

    public static function WriteText(string $file, string $content): bool
    {
        file_put_contents("generated/$file", $content);
        return file_exists("generated/$file");
    }

    public static function ReadText(string $file): string
    {
        if (self::IsPlainText($file)) {
            return file_get_contents("data/$file");
        }
        return "";
    }

    private static function IsPlainText(string $file): bool
    {
        $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), "data/$file");
        return strpos($mime, "text") === 0;
    }
}
