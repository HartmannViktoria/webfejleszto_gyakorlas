<?php

class Controller {

    public static function Init(): void {
        if (isset($_SESSION["auth"]) && $_SESSION["auth"]) {
            View::Init("index.html");
        } else {
            View::Init("welcome.html");
        }
    }

    public static function Route() {
        $page = isset($_GET["page"]) ? htmlspecialchars($_GET["page"]) : "index";

        if ($page == "index") {
            // Az index oldalt csak bejelentkezés után mutatjuk
            if (!isset($_SESSION["auth"]) || !$_SESSION["auth"]) {
                self::WelcomeController();
                return;
            }
        }

        $pages = Model::ReadCSV("pages");
        $pageData = "";
        foreach ($pages["data"] as $pageRow) {
            if ($pageRow[0] == $page) {
                $pageData = $pageRow;
                break;
            }
        }

        if ($pageData != "") {
            call_user_func(array("Controller", ucfirst($page) . "Controller"));
        } elseif ($page == "logout") {
            self::LogoutController();
        } else {
            self::Error404Controller();
        }
    }

    private static function WelcomeController(): void {
        View::getBaseTemplate()->AddData("TITLE", "Welcome Page");
        View::FinalRender();
    }

    private static function IndexController(): void {
        $content = Template::Load("main.html");
        $content->TITLE = "Főoldal";

        if (isset($_SESSION["auth"]) && $_SESSION["auth"]) {
            $content->WELCOME = "Üdvözöllek {$_SESSION["name"]} az oldalamon!";
            $content->LOGOUT_LINK = '<a href="?page=logout">Kijelentkezés</a>';
        } else {
            $content->WELCOME = "Üdvözöllek!";
            $content->LOGOUT_LINK = "";
        }

        View::getBaseTemplate()->AddData("CONTENT", $content->Render());
        View::getBaseTemplate()->AddData("TITLE", "Az MVC oldalunk főoldala");
    }

    private static function RegisterController(): void {
        $registerForm = Template::Load("register.html");
        $registerForm->AddData("TITLE", "Regisztráció");

        if (isset($_POST["ok"])) {
            $writeback = true;
            $name = isset($_POST["fullname"]) ? htmlspecialchars($_POST["fullname"]) : "";
            $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
            $birthplace = isset($_POST["birthplace"]) ? htmlspecialchars($_POST["birthplace"]) : "";
            $birthdate = isset($_POST["birthdate"]) ? $_POST["birthdate"] : "";
            $pass = isset($_POST["pass"]) ? htmlspecialchars($_POST["pass"]) : "";
            $pass2 = isset($_POST["pass2"]) ? htmlspecialchars($_POST["pass2"]) : "";

            if (!empty($name) && filter_var($email, FILTER_VALIDATE_EMAIL) &&
                    !empty($birthplace) && !empty($birthdate) && !empty($pass) && !empty($pass2)) {
                if ($email == filter_input(INPUT_POST, "email2", FILTER_SANITIZE_EMAIL)) {
                    if ($pass == $pass2) {
                        if (preg_match("/[0-9]+/", $pass) && strtolower($pass) != $pass &&
                                strtoupper($pass) != $pass && mb_strlen($pass) >= 8) {
                            Model::WriteCSV("users", array(array($name, $email, $birthplace, $birthdate, hash("sha256", $pass))), ";", true);
                            $registerForm->AddData("RESULT", "Sikeres regisztráció!");
                            $registerForm->AddData("RESULTCLASS", "success");
                            $writeback = false;
                        } else {
                            $registerForm->AddData("RESULT", "Gyenge jelszó! A jelszónak legalább 8 karakteresnek kell lennie, melyben kis-nagy betű és szám is szerepel!");
                            $registerForm->AddData("RESULTCLASS", "fail");
                        }
                    } else {
                        $registerForm->AddData("RESULT", "Nem egyező jelszavak!");
                        $registerForm->AddData("RESULTCLASS", "fail");
                    }
                } else {
                    $registerForm->AddData("RESULT", "Nem egyező email címek!");
                    $registerForm->AddData("RESULTCLASS", "fail");
                }
            } else {
                $registerForm->AddData("RESULT", "Hiányos adatok!");
                $registerForm->AddData("RESULTCLASS", "fail");
            }

            if ($writeback) {
                $registerForm->AddData("NAME", $name);
                $registerForm->AddData("EMAIL", $email);
                $registerForm->AddData("BIRTHPLACE", $birthplace);
                $registerForm->AddData("BIRTHDATE", $birthdate);
            }
        }

        View::getBaseTemplate()->AddData("CONTENT", $registerForm->Render());
        View::getBaseTemplate()->AddData("TITLE", "Az MVC oldalunk regisztrációs oldala");
    }

    private static function LoginController(): void {
        $loginForm = Template::Load("login.html");
        $loginForm->AddData("TITLE", "Belépés");

        if (isset($_POST["ok"])) {
            if (filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && isset($_POST["pass"])) {
                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $pass = hash("sha256", htmlspecialchars($_POST["pass"]));
                $logins = Model::ReadCSV("users");
                $login = false;
                foreach ($logins["data"] as $row) {
                    if (trim($row[1]) == trim($email) && trim($row[2]) == trim($pass)) {
                        $login = true;
                        $_SESSION["name"] = $row[0];
                        break;
                    }
                }
                if ($login) {
                    $_SESSION["auth"] = true;
                    header("Location: index.php");
                    exit;
                } else {
                    $loginForm->AddData("RESULT", "Hibás felhasználónév / jelszó!");
                    $loginForm->AddData("RESULTCLASS", "fail");
                    session_destroy();
                }
            } else {
                $loginForm->AddData("RESULT", "Hiányos adatok!");
                $loginForm->AddData("RESULTCLASS", "fail");
                session_destroy();
            }
        }
        View::getBaseTemplate()->AddData("CONTENT", $loginForm->Render());
        View::getBaseTemplate()->AddData("TITLE", "Az MVC oldalunk belépés oldala");
    }

    private static function LogoutController(): void {
        session_destroy();
        $_SESSION["auth"] = false;
        header("Location: index.php");
    }

    private static function Error404Controller(): void {
        View::getBaseTemplate()->AddData("CONTENT", Template::Load("404.html")->Render());
        View::getBaseTemplate()->AddData("TITLE", "A megadott oldal nem található!");
    }
}
